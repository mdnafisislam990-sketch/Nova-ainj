package com.zara.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Foreground service so Zara keeps listening when you leave the call screen. */
class VoiceCallService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("zara_call", "Zara voice call", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = Notification.Builder(this, "zara_call")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zara is on a call")
            .setContentText("Tap to return. Swipe the app away or press End to stop.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, notification)

        LiveSession.start(applicationContext)
        scope.launch { LiveSession.state.collect { if (it == CallState.ERROR) stopSelf() } }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        LiveSession.stop()
        super.onDestroy()
    }
}

fun beginCall(ctx: Context) {
    LiveSession.clear()
    ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceCallService::class.java))
}

fun endCall(ctx: Context) {
    ctx.stopService(Intent(ctx, VoiceCallService::class.java))
    LiveSession.stop()
    LiveSession.clear()
}
