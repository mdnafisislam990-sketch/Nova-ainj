package com.zara.ai

import android.Manifest
import android.content.Context
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import kotlinx.coroutines.launch
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

internal val Night = Color(0xFF050511)
internal val Card = Color(0xFF111027)
internal var Purple by mutableStateOf(Color(0xFF9C4DFF))
internal val Lavender = Color(0xFFC5A5FF)
internal val Soft = Color(0xFF9994B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Memory.load(applicationContext)
        Purple = Color(Prefs.accent(applicationContext))
        window.statusBarColor = android.graphics.Color.rgb(5, 5, 17)
        window.navigationBarColor = android.graphics.Color.rgb(5, 5, 17)
        setContent { ZaraApp() }
    }
}

@Composable
fun ZaraApp() {
    var tab by remember { mutableStateOf("Home") }
    var prompt by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val callState by LiveSession.state.collectAsState()
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) { beginCall(ctx); tab = "Call" }
        else Toast.makeText(ctx, "Microphone permission is needed to talk with Zara", Toast.LENGTH_LONG).show()
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == android.app.Activity.RESULT_OK && !said.isNullOrBlank()) prompt = (prompt + " " + said).trim()
    }
    val dictate: () -> Unit = {
        try {
            speechLauncher.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.sttLang(ctx))
            )
        } catch (e: Exception) {
            Toast.makeText(ctx, "Speech input is not available on this phone", Toast.LENGTH_LONG).show()
        }
    }
    val startCall: () -> Unit = {
        when {
            callState != CallState.IDLE && callState != CallState.ERROR -> tab = "Call"
            Prefs.apiKey(ctx).isBlank() -> { Toast.makeText(ctx, "Add your Gemini API key in Settings > Connections", Toast.LENGTH_LONG).show(); tab = "Settings" }
            else -> {
                val wanted = listOf(
                    Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS
                )
                val missing = wanted.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) { beginCall(ctx); tab = "Call" }
                else micLauncher.launch(missing.toTypedArray())
            }
        }
    }
    val sendText: (String) -> Unit = { value ->
        if (value.isNotBlank()) { ChatClient.ask(ctx, value.trim()); prompt = ""; tab = "Chat" }
    }
    BackHandler(enabled = tab != "Home" && tab != "Call") { tab = "Home" }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Night, surface = Card)) {
        Box(Modifier.fillMaxSize().background(Night)) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        "Chat" -> ChatPage(prompt, { prompt = it }, sendText, { tab = "Home" }, dictate)
                        "Call" -> CallScreen(onMinimize = { tab = "Home" }, onEnd = { endCall(ctx); tab = "Home" })
                        "Settings" -> SettingsPage { tab = "Home" }
                        "History" -> HistoryPage(open = { Memory.openSession(it); tab = "Chat" }, onNew = { Memory.newSession(); tab = "Chat" })
                        "Create Image" -> ImagePage { tab = "Home" }
                        "Write" -> WritePage(onPick = { starter -> prompt = starter; tab = "Chat" }) { tab = "Home" }
                        else -> HomePage(prompt, { prompt = it }, sendText, callState != CallState.IDLE && callState != CallState.ERROR, { startCall() }, { tab = it })
                    }
                }
                if (tab != "Call") BottomBar(tab, { tab = it }, { startCall() })
            }
        }
    }
}

@Composable
private fun Header(onMenu: () -> Unit, onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        RoundIcon(Icons.Default.Menu, onMenu)
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ZARA", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text(" AI", color = Purple, fontSize = 29.sp, fontWeight = FontWeight.Black)
            }
            Text("Y O U R   A I   A S S I S T A N T", color = Soft, fontSize = 8.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.weight(1f))
        RoundIcon(Icons.Default.Settings, onSettings)
    }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Box(Modifier.size(48.dp).clip(RoundedCornerShape(17.dp)).background(Color(0xFF17162D)).border(1.dp, Color(0xFF30284A), RoundedCornerShape(17.dp)).clickable { click() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color(0xFFE8E2FF), modifier = Modifier.size(23.dp))
    }
}

@Composable
private fun HomePage(prompt: String, onPrompt: (String) -> Unit, send: (String) -> Unit, listening: Boolean, onVoice: () -> Unit, navigate: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header(onMenu = { navigate("History") }, onSettings = { navigate("Settings") })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(435.dp)) {
                Image(painterResource(R.drawable.zara_hero), contentDescription = "Zara assistant portrait", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Night.copy(alpha = .12f), Color.Transparent, Night.copy(alpha = .78f)))))
                Column(Modifier.align(Alignment.TopStart).padding(start = 28.dp, top = 35.dp)) {
                    Text("Hi,", color = Color(0xFFFFC9FF), fontSize = 25.sp, fontWeight = FontWeight.Light)
                    Text("I'm", color = Color(0xFFFFC9FF), fontSize = 25.sp, fontWeight = FontWeight.Light)
                    Text("ZARA", color = Color(0xFFFFC9FF), fontSize = 32.sp, fontWeight = FontWeight.Light)
                    Text("♡", color = Color(0xFFFFC9FF), fontSize = 24.sp)
                }
                Column(Modifier.align(Alignment.TopEnd).padding(end = 24.dp, top = 48.dp), horizontalAlignment = Alignment.End) {
                    Text("Always", color = Lavender, fontSize = 19.sp)
                    Text("Here For", color = Lavender, fontSize = 19.sp)
                    Text("You ♡", color = Lavender, fontSize = 19.sp)
                }
                Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 0.dp).size(190.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF5522A6), Color(0xCC170D37), Color.Transparent))).border(5.dp, Brush.sweepGradient(listOf(Purple, Color(0xFFFF83D7), Color(0xFF8DABFF), Purple)), CircleShape).clickable { onVoice() }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(158.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF241747), Color(0xFF0C0A20)))).border(2.dp, Color(0xFF47316D), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Mic, null, tint = Lavender, modifier = Modifier.size(48.dp))
                    }
                }
            }
            Text(if (listening) "Zara is on call - tap to open" else "Tap to Talk", color = Color(0xFFF0E9FF), fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
            Text("•  •  •  ┃  •  •  •  ┃  •  •  •", color = Purple, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp).height(66.dp).clip(RoundedCornerShape(32.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF17152F), Color(0xFF0F0E22)))).border(1.dp, Color(0xFF4B2C76), RoundedCornerShape(32.dp)).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF2A1A4D)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Purple) }
                BasicTextField(value = prompt, onValueChange = onPrompt, modifier = Modifier.weight(1f).padding(horizontal = 14.dp), textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = Brush.verticalGradient(listOf(Purple, Lavender)), decorationBox = { inner -> if (prompt.isEmpty()) Text("Ask me anything...", color = Soft, fontSize = 16.sp); inner() })
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF9B4EFF), Color(0xFF6332D8)))).clickable { send(prompt) }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Send, null, tint = Color.White) }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Chat", "Get instant answers", Icons.Default.ChatBubbleOutline, Modifier.weight(1f)) { navigate("Chat") }
                ActionCard("Create Image", "Photos into sketches", Icons.Default.Image, Modifier.weight(1f)) { navigate("Create Image") }
                ActionCard("Write", "Notes, code, content", Icons.Default.Description, Modifier.weight(1f)) { navigate("Write") }
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, click: () -> Unit) {
    Column(modifier.height(150.dp).clip(RoundedCornerShape(25.dp)).background(Brush.verticalGradient(listOf(Color(0xFF17152F), Color(0xFF0D0D1D)))).border(1.dp, Color(0xFF35234F), RoundedCornerShape(25.dp)).clickable { click() }.padding(horizontal = 7.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(55.dp).clip(CircleShape).background(Color(0xFF292149)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Lavender, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.height(9.dp)); Text(title, color = Color(0xFFF0EDFF), fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center); Text(sub, color = Soft, fontSize = 10.sp, lineHeight = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun BottomBar(tab: String, navigate: (String) -> Unit, onOrb: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp).height(82.dp).clip(RoundedCornerShape(42.dp)).background(Brush.verticalGradient(listOf(Color(0xFF27204C), Color(0xFF17142E)))).border(1.dp, Color(0xFF39305E), RoundedCornerShape(42.dp)).padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceAround) {
        BottomItem("Home", Icons.Default.Home, tab == "Home") { navigate("Home") }
        BottomItem("Chat", Icons.Default.Chat, tab == "Chat") { navigate("Chat") }
        Box(Modifier.size(66.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFB07AFF), Color(0xFF5525B5), Color(0xFF24133F)))).border(2.dp, Color(0xFFFFC66D), CircleShape).clickable { onOrb() }, contentAlignment = Alignment.Center) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFB98AFF), Color(0xFF5424B4), Color(0xFF201039)))))
        }
        BottomItem("History", Icons.Default.History, tab == "History") { navigate("History") }
        BottomItem("Settings", Icons.Default.Settings, tab == "Settings") { navigate("Settings") }
    }
}

@Composable
private fun BottomItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, click: () -> Unit) {
    Column(Modifier.clickable { click() }.width(58.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = if (selected) Color(0xFFFFB83D) else Color(0xFF9690B4), modifier = Modifier.size(23.dp))
        Text(label, color = if (selected) Color(0xFFFFB83D) else Color(0xFF9690B4), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
        if (selected) Box(Modifier.padding(top = 3.dp).width(22.dp).height(3.dp).clip(CircleShape).background(Color(0xFFFFB83D)))
    }
}

@Composable
private fun ChatPage(prompt: String, onPrompt: (String) -> Unit, send: (String) -> Unit, back: () -> Unit, onMic: () -> Unit) {
    val ver by Memory.version.collectAsState()
    val msgs = remember(ver) { Memory.messages() }
    val streaming by ChatClient.streaming.collectAsState()
    val error by ChatClient.error.collectAsState()
    val listState = rememberLazyListState()
    val s = streaming
    val e = error
    val count = msgs.size + (if (s != null) 1 else 0) + (if (e != null) 1 else 0)
    LaunchedEffect(count, s?.length) { if (count > 0) listState.scrollToItem(count - 1) }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { back() })
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text("Zara AI", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("Remembers your chats, calls and actions", color = Soft, fontSize = 11.sp) }
            RoundIcon(Icons.Default.Add) { Memory.newSession() }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (count == 0) Text("Hello! I'm Zara. How can I help you today?", color = Color.White, modifier = Modifier.fillMaxWidth().padding(top = 80.dp), textAlign = TextAlign.Center)
            LazyColumn(Modifier.fillMaxSize(), state = listState, verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                itemsIndexed(msgs) { _, m ->
                    if (m.role == "action") Text("\uD83D\uDCF1 " + m.text, color = Soft, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    else Bubble(m.role == "user", m.text, m.src == "voice")
                }
                if (s != null) item { Bubble(false, s.ifEmpty { "\u2026" }, false) }
                if (e != null) item { Text("\u26A0 $e", color = Color(0xFFFF8A8A), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp)) }
            }
        }
        ChatInput(prompt, onPrompt, send, onMic)
    }
}

@Composable
private fun Bubble(user: Boolean, text: String, voice: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Text((if (voice) "\uD83C\uDF99 " else "") + text, color = Color.White, fontSize = 14.sp,
            modifier = Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(18.dp)).background(if (user) Color(0xFF4D287E) else Card).padding(14.dp))
    }
}

@Composable
private fun ChatInput(prompt: String, onPrompt: (String) -> Unit, send: (String) -> Unit, onMic: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp).clip(RoundedCornerShape(28.dp)).background(Card).border(1.dp, Color(0xFF43305F), RoundedCornerShape(28.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(prompt, onPrompt, Modifier.weight(1f).padding(12.dp), textStyle = TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = Brush.verticalGradient(listOf(Purple, Lavender)), decorationBox = { inner -> if (prompt.isEmpty()) Text("Message Zara...", color = Soft); inner() })
        IconButton(onClick = onMic) { Icon(Icons.Default.Mic, null, tint = Soft) }
        IconButton(onClick = { send(prompt) }) { Icon(Icons.Default.Send, null, tint = Lavender) }
    }
}

@Composable
private fun SettingsPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf("") }
    var tick by remember { mutableStateOf(0) }
    val ver by Memory.version.collectAsState()
    val close: () -> Unit = { dialog = ""; tick++ }
    @Suppress("UNUSED_VARIABLE") val refresh = tick + ver
    when (dialog) {
        "Connections" -> ConnectionsDialog(close)
        "Phone control" -> PhoneControlDialog(close)
        "About Zara", "Privacy & about" -> AboutDialog(close)
        "Voice & language" -> VoiceLangDialog(close)
        "Chats & memory" -> MemoryDialog(close)
        "Look & feel" -> LookFeelDialog(close)
        "Voice keyboard" -> KeyboardDialog(close)
        "Call settings" -> CallSettingsDialog(close)
    }
    val onRow: (String) -> Unit = { dialog = it }
    val (nFacts, nChats) = Memory.counts()
    val accentName = Prefs.ACCENTS.firstOrNull { it.second == Prefs.accent(ctx) }?.first ?: "Purple"
    val sttName = Prefs.STT.firstOrNull { it.second == Prefs.sttLang(ctx) }?.first ?: "English"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { back() }); Spacer(Modifier.width(14.dp)); Text("ZARA AI Settings", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        Text("Customize your AI experience", color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
        SettingGroup("AI SETTINGS", listOf(
            "Connections" to "Gemini key, models & voice",
            "Voice & language" to "${Prefs.voice(ctx)} • ${Prefs.language(ctx)}",
            "Chats & memory" to "$nChats chats • $nFacts saved facts"), onClick = onRow)
        SettingGroup("APP SETTINGS", listOf(
            "Look & feel" to "Dark • $accentName",
            "Voice keyboard" to "Dictation • $sttName",
            "Call settings" to (if (Prefs.speaker(ctx)) "Speaker on" else "Speaker off") + " • " + (if (Prefs.confirmSensitive(ctx)) "Confirms risky actions" else "No confirmations"),
            "Phone control" to (if (PhoneControl.isEnabled(ctx)) "ON • tap, swipe, screen" else "OFF • tap to enable")), onClick = onRow)
        SettingGroup("ABOUT", listOf("Privacy & about" to "Your data stays on this phone", "About Zara" to "Created by NAFIZ bhaiya • @mdnafis568"), onClick = onRow)
        Text("Tap Connections and paste your Gemini API key to enable live voice calls and chat.", color = Soft, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(8.dp))
    }
}

@Composable
private fun SettingGroup(title: String, rows: List<Pair<String, String>>, onClick: (String) -> Unit = {}) {
    Text(title, color = Lavender, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
    rows.forEach { (name, detail) -> Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Color(0xFF292342), RoundedCornerShape(16.dp)).clickable { onClick(name) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF30204D)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Lavender, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(detail, color = Soft, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Soft)
    } }
}

@Composable
private fun HistoryPage(open: (String) -> Unit, onNew: () -> Unit) {
    val ver by Memory.version.collectAsState()
    val list = remember(ver) { Memory.sessionList() }
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("History", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Your saved conversations", color = Soft, fontSize = 12.sp) }
            RoundIcon(Icons.Default.Add, onNew)
        }
        Spacer(Modifier.height(18.dp))
        if (list.isEmpty()) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).clickable { onNew() }.padding(25.dp), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.History, null, tint = Lavender, modifier = Modifier.size(34.dp)); Text("No saved chats yet", color = Color.White, fontWeight = FontWeight.SemiBold); Text("Start a conversation with Zara", color = Soft, fontSize = 11.sp) } }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { s ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Color(0xFF292342), RoundedCornerShape(18.dp)).clickable { open(s.id) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(android.text.format.DateUtils.getRelativeTimeSpanString(s.updated, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS).toString() + " • " + s.count + " messages", color = Soft, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.Delete, null, tint = Soft, modifier = Modifier.padding(start = 8.dp).clickable { Memory.deleteSession(s.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun WritePage(onPick: (String) -> Unit, back: () -> Unit) {
    val items = listOf(
        "Email" to "Write a professional email about: ",
        "Story" to "Write a short story about: ",
        "Code" to "Write code that does this: ",
        "Notes" to "Organize these notes into a clean summary: ",
        "Social post" to "Write a catchy social media post about: ",
        "Translate" to "Translate this to English: "
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { back() }); Spacer(Modifier.width(12.dp)); Text("Write with Zara", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        Text("Pick what to write, then finish the sentence in chat", color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))
        items.forEach { (name, starter) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Color(0xFF292342), RoundedCornerShape(16.dp)).clickable { onPick(starter) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Description, null, tint = Lavender); Spacer(Modifier.width(12.dp))
                Text(name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Soft)
            }
        }
    }
}

@Composable
private fun ImagePage(back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var bmp by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { back() }); Spacer(Modifier.width(12.dp)); Text("Create Image", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        Text("Describe the image you want", color = Soft, fontSize = 12.sp)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Color(0xFF43305F), RoundedCornerShape(18.dp)).padding(14.dp)) {
            BasicTextField(prompt, { prompt = it }, Modifier.fillMaxWidth().heightIn(min = 70.dp), textStyle = TextStyle(color = Color.White, fontSize = 15.sp), cursorBrush = Brush.verticalGradient(listOf(Purple, Lavender)), decorationBox = { inner -> if (prompt.isEmpty()) Text("A cute robot reading a book, watercolor...", color = Soft, fontSize = 15.sp); inner() })
        }
        Button(onClick = {
            if (prompt.isNotBlank() && !busy) scope.launch { busy = true; err = null; val (b, e) = ImageClient.generate(ctx, prompt.trim()); if (b != null) bmp = b; err = e; busy = false }
        }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Purple), modifier = Modifier.fillMaxWidth().height(50.dp)) {
            Text(if (busy) "Creating..." else "Generate", color = Color.White)
        }
        if (busy) CircularProgressIndicator(color = Purple, modifier = Modifier.align(Alignment.CenterHorizontally))
        err?.let { Text("\u26A0 $it", color = Color(0xFFFF8A8A), fontSize = 12.sp) }
        bmp?.let { b ->
            Image(b.asImageBitmap(), "Generated image", Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)))
            OutlinedButton(onClick = { Toast.makeText(ctx, saveImage(ctx, b), Toast.LENGTH_LONG).show() }, modifier = Modifier.fillMaxWidth()) { Text("Save to gallery", color = Lavender) }
        }
    }
}

private fun saveImage(ctx: Context, b: android.graphics.Bitmap): String {
    if (android.os.Build.VERSION.SDK_INT < 29) return "Saving needs Android 10 or newer"
    return try {
        val v = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "zara_" + System.currentTimeMillis() + ".png")
            put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Zara")
        }
        val uri = ctx.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return "Could not save"
        ctx.contentResolver.openOutputStream(uri)?.use { b.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        "Saved to Pictures/Zara"
    } catch (e: Exception) { "Could not save: " + e.message }
}

@Composable
private fun ConnectionsDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.apiKey(ctx)) }
    var model by remember { mutableStateOf(Prefs.model(ctx)) }
    var voice by remember { mutableStateOf(Prefs.voice(ctx)) }
    var textModel by remember { mutableStateOf(Prefs.textModel(ctx)) }
    var imageModel by remember { mutableStateOf(Prefs.imageModel(ctx)) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Card,
        title = { Text("Gemini Live", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(model, { model = it }, label = { Text("Live model") }, singleLine = true)
                OutlinedTextField(voice, { voice = it }, label = { Text("Voice (e.g. Aoede, Puck, Kore)") }, singleLine = true)
                OutlinedTextField(textModel, { textModel = it }, label = { Text("Chat model") }, singleLine = true)
                OutlinedTextField(imageModel, { imageModel = it }, label = { Text("Image model") }, singleLine = true)
                Text("Changing the key never deletes your chats or memory.", color = Soft, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = { Prefs.save(ctx, key, model, voice); Prefs.put(ctx, "text_model", textModel); Prefs.put(ctx, "image_model", imageModel); onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}


private fun openTelegram(ctx: Context) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/mdnafis568")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}

@Composable
private fun AboutDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Card,
        title = { Text("About Zara", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Zara AI - your personal AI assistant with live voice calls and phone control.", color = Soft)
                Text("Ami NAFIZ vaiya ar toiri, se amke toiri korse.", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Privacy: your API key, chats and memory are stored only on this phone. Audio and text go to Google Gemini to get replies.", color = Soft, fontSize = 11.sp)
                Text("Telegram channel: @mdnafis568", color = Lavender, modifier = Modifier.clickable { openTelegram(ctx) })
            }
        },
        confirmButton = { TextButton(onClick = { openTelegram(ctx) }) { Text("Open Telegram") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable
private fun PhoneControlDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val on = PhoneControl.isEnabled(ctx)
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Card,
        title = { Text("Phone control", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (on) "Status: ON - Zara can see your screen, tap, swipe and type when you ask her during a call." else "Status: OFF", color = if (on) Color(0xFF7DFFB0) else Color(0xFFFFB83D), fontWeight = FontWeight.SemiBold)
                Text("1. Tap 'Open Accessibility settings'.\n2. Open 'Zara Phone Control' (may be under Installed apps) and turn it ON.\n3. If Android says 'Restricted setting': Settings > Apps > Zara > menu (3 dots) > Allow restricted settings, then retry.\n4. Start a call and say e.g. 'open YouTube' or 'scroll down'.", color = Soft, fontSize = 12.sp, lineHeight = 17.sp)
                Text("Zara asks before sensitive actions. You can turn this off any time in Accessibility settings.", color = Soft, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                try { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }) { Text("Open Accessibility settings") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
